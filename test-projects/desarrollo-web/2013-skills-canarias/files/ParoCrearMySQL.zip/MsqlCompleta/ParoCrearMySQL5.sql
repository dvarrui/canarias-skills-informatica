
-- Claves externas

USE `paro`;

alter table Municipios
add constraint FK_MunicipiosProvincias
foreign key (CodProvincia)
references Provincias (CodProvincia);


alter table Provincias
add constraint FK_ProvinciasCA
foreign key (CodCA)
references ComunidadesAutonomas (CodCA);


alter table MunicipiosIslas
add constraint FK_MunicipiosIslas1
foreign key (CodMunicipio)
references Municipios (CodMunicipio);


alter table MunicipiosIslas
add constraint FK_MunicipiosIslas2
foreign key (CISLA)
references Islas (CISLA);


alter table Padron
add constraint FK_PadronMunicipio
foreign key (CodMunicipio)
references Municipios (CodMunicipio);


alter table ParoMes
add constraint FK_ParoMesMunicipio
foreign key (CodMunicipio)
references Municipios (CodMunicipio);
